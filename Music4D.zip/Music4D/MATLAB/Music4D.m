function Music4D(wavfile, rm, mic, src)

[audioRL,fs,N,opts]=wavread(wavfile);
audio=audioRL(:,1);
r=0.99;%reflection coefficients
n=1;%reflection times
nn=-n:1:n; % Index for the sequence
x=1;
rms=nn+0.5-0.5*(-1).^nn;              % Part of equations 22, 23,24,& 25
srcs=(-1).^(nn);                      % part of equations 22, 23,24,& 25
xi=srcs*src(1)+rms*rm(1)-mic(1);      % Equation 22 
yj=srcs*src(2)+rms*rm(2)-mic(2);      % Equation 23 
zk=srcs*src(3)+rms*rm(3)-mic(3);      % Equation 24 

[i,j,k]=meshgrid(xi,yj,zk);           % convert vectors to 3D matrices
d=sqrt(i.^2+j.^2+k.^2);               % Equation 25

[e,f,g]=meshgrid(nn, nn, nn);         % convert vectors to 3D matrices
c=r.^(abs(e)+abs(f)+abs(g));          % decay rate

time=round(fs*d/343)+1;               % time delay
loss=c./(d.^2);    % sound energy loss

delay_length=max(max(max(time)));
x_length=length(x);
total_length=delay_length+x_length;

x_echo=zeros(total_length,3,3,3);

for i_index = 1:2*n+1
    for j_index = 1:2*n+1
        for k_index = 1:2*n+1
            zero_no=time(i_index,j_index,k_index);
            x_echo(:,i_index,j_index,k_index)=loss(i_index,j_index,k_index)*[zeros(zero_no,1);x;zeros(delay_length-zero_no,1)];
        end
    end
end

%calculate azimuthal angle and elevation, origin: listener's head
D_xy=sqrt(i.^2+j.^2);
E_angle=asin(k./d);
A1_angle=asin(j./D_xy);
A2_angle=acos(i./D_xy);
axis1=i./D_xy;
axis2=j./D_xy;
for i_index = 1:2*n+1
    for j_index = 1:2*n+1
        for k_index = 1:2*n+1
           if i(i_index,j_index,k_index)>0 && j(i_index,j_index,k_index)>0
               A_angle(i_index,j_index,k_index)=A1_angle(i_index,j_index,k_index);
           elseif i(i_index,j_index,k_index)<0 && j(i_index,j_index,k_index)>0
               A_angle(i_index,j_index,k_index)=A2_angle(i_index,j_index,k_index);
           elseif i(i_index,j_index,k_index)<0 && j(i_index,j_index,k_index)<0
               A_angle(i_index,j_index,k_index)=2*pi-A2_angle(i_index,j_index,k_index);
           elseif i(i_index,j_index,k_index)>0 && j(i_index,j_index,k_index)<0
               A_angle(i_index,j_index,k_index)=A1_angle(i_index,j_index,k_index);
           elseif axis1(i_index,j_index,k_index)==1 && axis2(i_index,j_index,k_index)==0
               A_angle(i_index,j_index,k_index)=0;
           elseif axis1(i_index,j_index,k_index)==0 && axis2(i_index,j_index,k_index)==1
               A_angle(i_index,j_index,k_index)=0.5*pi;
           elseif axis1(i_index,j_index,k_index)==-1 && axis2(i_index,j_index,k_index)==0
               A_angle(i_index,j_index,k_index)=pi;
           elseif axis1(i_index,j_index,k_index)==0 && axis2(i_index,j_index,k_index)==-1
               A_angle(i_index,j_index,k_index)=1.5*pi;
           else
               A_angle(i_index,j_index,k_index)=1000000;
           end
        end
    end
end
%----- Ambisonic Encoding--------
W_c=zeros(total_length,27);
X_c=zeros(total_length,27);
Y_c=zeros(total_length,27);
Z_c=zeros(total_length,27);
R_c=zeros(total_length,27);
S_c=zeros(total_length,27);
T_c=zeros(total_length,27);
U_c=zeros(total_length,27);
V_c=zeros(total_length,27);
index=0;
for i_index = 1:2*n+1
    for j_index = 1:2*n+1
        for k_index = 1:2*n+1
            index=index+1;
            W_c(:,index)=(1/sqrt(2))*x_echo(:,i_index,j_index,k_index);
            X_c(:,index)=cos(A_angle(i_index,j_index,k_index))*cos(E_angle(i_index,j_index,k_index))*x_echo(:,i_index,j_index,k_index);
            Y_c(:,index)=sin(A_angle(i_index,j_index,k_index))*cos(E_angle(i_index,j_index,k_index))*x_echo(:,i_index,j_index,k_index);
            Z_c(:,index)=sin(E_angle(i_index,j_index,k_index))*x_echo(:,i_index,j_index,k_index);
            R_c(:,index)=(1.5*(sin(E_angle(i_index,j_index,k_index)))^2-0.5)*x_echo(:,i_index,j_index,k_index);
            S_c(:,index)=cos(A_angle(i_index,j_index,k_index))*sin(2*E_angle(i_index,j_index,k_index))*x_echo(:,i_index,j_index,k_index);
            T_c(:,index)=sin(A_angle(i_index,j_index,k_index))*sin(2*E_angle(i_index,j_index,k_index))*x_echo(:,i_index,j_index,k_index);
            U_c(:,index)=cos(2*A_angle(i_index,j_index,k_index))*(cos(E_angle(i_index,j_index,k_index)))^2*x_echo(:,i_index,j_index,k_index);
            V_c(:,index)=sin(2*A_angle(i_index,j_index,k_index))*(cos(E_angle(i_index,j_index,k_index)))^2*x_echo(:,i_index,j_index,k_index);
            
        end
    end
end
hW=zeros(total_length,1);
hX=zeros(total_length,1);
hY=zeros(total_length,1);
hZ=zeros(total_length,1);
hR=zeros(total_length,1);
hS=zeros(total_length,1);
hT=zeros(total_length,1);
hU=zeros(total_length,1);
hV=zeros(total_length,1);
for mm_index=1:1:27
    hW=hW+W_c(:,mm_index);
    hX=hX+X_c(:,mm_index);
    hY=hY+Y_c(:,mm_index);
    hZ=hZ+Z_c(:,mm_index);
    hR=hR+R_c(:,mm_index);
    hS=hS+S_c(:,mm_index);
    hT=hT+T_c(:,mm_index);
    hU=hU+U_c(:,mm_index);
    hV=hV+V_c(:,mm_index);
end
% see Fig 16
yW=filter(hW,1,audio);

yX=filter(hX,1,audio);

yY=filter(hY,1,audio);

yZ=filter(hZ,1,audio);

yR=filter(hR,1,audio);

yS=filter(hS,1,audio);

yT=filter(hT,1,audio);

yU=filter(hU,1,audio);

yV=filter(hV,1,audio);

WX(:,1)=yW;
WX(:,2)=yX;
YZ(:,1)=yY;
YZ(:,2)=yZ;
RS(:,1)=yR;
RS(:,2)=yS;
TU(:,1)=yT;
TU(:,2)=yU;
V(:,1)=yV;
V(:,2)=yV;

wavwrite(WX,fs,N,'WX.wav');
wavwrite(YZ,fs,N,'YZ.wav');
wavwrite(RS,fs,N,'RS.wav');
wavwrite(TU,fs,N,'TU.wav');
wavwrite(V,fs,N,'V.wav');
end